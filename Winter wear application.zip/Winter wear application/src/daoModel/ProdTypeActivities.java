/**
 * Name : Priyanka Jagadesh Kumar 
 * Source File Name : ProdTypeActivities.java
 * Phase-2: Winter wear Application
 * @author Priyanka Jagadesh Kumar
 * This class contains all the product type activities  
 * 
 **/
package daoModel;

import java.util.List;

import model.ProductType;

public interface ProdTypeActivities {
	//contains the activities for the product type table 
	public List<ProductType> fetchType();//fetches the product types from the product type table
	
	public List<ProductType> viewProductType();//view the product type list from the table
	
	public boolean insertProType(String typeName);//inserts product type to the table

	public boolean deleteProType(int typeID);//deletes a product type
	
	
}
