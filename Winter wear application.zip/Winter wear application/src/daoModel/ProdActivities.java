/**
 * Name : Priyanka Jagadesh Kumar 
 * Source File Name : ProdActivities.java
 * Phase-2: Winter wear Application
 * @author Priyanka Jagadesh Kumar
 * This class contains all the activities related the products  
 * 
 **/
package daoModel;

import java.util.List;

import model.ProductInfo;
//contains the activities for the products table
public interface ProdActivities {
	public boolean createProduct(String productName,String productType , String availability, Double productPrice, String color, String size , int productTypeID );//creates a new product
	
	public List<ProductInfo> fetchProduct();//fetches the product details 
	
	public int fetchItemID(String product_name);//fetches the product ID using the product name
	
	public boolean deleteProduct(int proID);//deletes a product
}