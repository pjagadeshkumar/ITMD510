/**
 * Name : Priyanka Jagadesh Kumar 
 * Source File Name : CustDAO.java
 * Phase-2: Winter wear Application
 * @author Priyanka Jagadesh Kumar
 * This Dao class contains queries related to Customer and Transaction tables  
 * 
 **/
package daoModel;

import java.sql.Connection;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import Controller.CustLoginCont;
import model.CustomerDetails;
import model.TransactionDetails;

//this class extending CustActivities implements the functions declared in the customer interface 
public class CustDAO implements CustActivities {
//establishing connection
	static Connector connect = new Connector();
	static Connection conn;
	static Statement statement = null;
	static CustomerDetails cd = CustLoginCont.getCustomer(); //creates an object for the CustomerDetails.java class

	//this method executes an sql query to insert customer details into the customer table
	public boolean newCustomer(String cus_lastname, String cus_firstname, String cus_loginID, String cus_password,
			String address1, String address2, String country, String state, int pinCode) {
		try {
			statement = connect.getConnection().createStatement();
			String cussql = "INSERT INTO cust_table (cus_firstname, cus_lastname, cus_loginID, cus_password, address1, address2, Country, state, pinCode)"
					+ "VALUES ('" + cus_firstname + "','" + cus_lastname + "','" + cus_loginID + "','" + cus_password
					+ "','" + address1 + "','" + address2 + "','" + country + "','" + state + "'," + pinCode + ")";
			statement.executeUpdate(cussql);
			System.out.println("Query successfully executed!");		
			statement.close();
		} catch (SQLException e) {
			e.getMessage();
			e.printStackTrace();
			return false;
		}
		return true;//returns true of the execution of query is successful

	}
	//this method executes an sql query to update customer details in the customer table
	public boolean updateCustomer(String cus_firstname, String cus_lastname, String cus_loginID, String cus_password,
			String address1, String address2, String country, String state, int pinCode) {
		try {
			statement = connect.getConnection().createStatement();
			int customerID = cd.getCustomerID();
			String cussql = "UPDATE cust_table SET cus_firstname ='" + cus_firstname + "', cus_lastname='"
					+ cus_lastname + "', cus_loginID ='" + cus_loginID + "', cus_password ='" + cus_password
					+ "',address1='" + address1 + "',address2='" + address2 + "', country= '" + country + "', state='"
					+ state + "', pinCode='" + pinCode + "' WHERE customerID =" + customerID;
			statement.executeUpdate(cussql);
			System.out.println("Query successfully executed!");	
			statement.close();

		} catch (SQLException e) {
			e.getMessage();
			e.printStackTrace();
			
			return false;
		}
		return true;//returns true of the execution of query is successful
	}
	//this method executes an sql query to create transaction in the transaction table
	public boolean createTransaction(String productName, int quantity, double totalPrice, int customerID, int productID) {
		try {
			int custID = cd.getCustomerID();
			statement = connect.getConnection().createStatement();
			String timeStamp = new SimpleDateFormat("yyyy/MM/dd").format(Calendar.getInstance().getTime()); //this records the current date on which the transaction occurs
			System.out.println("TimeStamp: " + timeStamp);
			String cussql = "INSERT INTO transaction_table (productName, quantity, totalPrice, tranDate, customerID, productID) VALUES ('"
					+productName+"',"+ quantity + "," + totalPrice + ",'"+ timeStamp +"' ,"+custID+"," +productID+")";
			statement.executeUpdate(cussql);
			System.out.println("Query successfully executed!");	
			statement.close();
		} catch (SQLException e) {
			e.getMessage();
			e.printStackTrace();
			return false;
		}
		return true;//returns true of the execution of query is successful
	}
	//this method executes an sql query to list the transactions in the transaction table
	public List<TransactionDetails> fetchTransaction() {
		try {
			List<TransactionDetails> tra = new ArrayList<>();
			ResultSet rs = null; //Initializing the result set
			int customerID = cd.getCustomerID();
			statement = connect.getConnection().createStatement();
			String cussql = "SELECT transaction_table.tranID, product_table.productName, transaction_table.quantity, transaction_table.totalPrice,transaction_table.tranDate "
					+ "FROM transaction_table, product_table WHERE transaction_table.productID = product_table.productID AND transaction_table.customerID = "
					+ customerID;
			rs = statement.executeQuery(cussql);
			System.out.println("Query successfully executed!");	
			while (rs.next()) {
				//creates an object for transaction details and sets all the items in the table to the object
				TransactionDetails trans = new TransactionDetails();
				trans.setTransactionID(rs.getInt(1));
				trans.setProductName(rs.getString(2));
				trans.setQuantity(rs.getInt(3));
				trans.setTotalPrice(rs.getDouble(4));
				trans.setTransactionDate(rs.getDate(5));
				tra.add(trans);
			}
			statement.close();
		} catch (SQLException e) {
			e.getMessage();

		}
		return null;
	}

}