/**
 * Name : Priyanka Jagadesh Kumar 
 * Source File Name : ProductInfoDAO.java
 * Phase-2: Winter wear Application
 * @author Priyanka Jagadesh Kumar
 * This Dao class contains queries related to Product and Administrator tables  
 * 
 **/
package daoModel;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import Controller.AdminLoginCont;
import model.AdminDetails;
import model.ProductInfo;

//this class extending ProdActivities implements the functions declared in the product interface 
public class ProductinfoDAO implements ProdActivities {
	//establishing connection
	Connector connect = new Connector();
	Connection conn;
	Statement statement = null;
	AdminDetails adm = AdminLoginCont.getAdmin();
    
	//this method executes an sql query to insert a product details into the product table
	public boolean createProduct(String productName,String productType , String availability, Double productPrice, String color, String size , int productTypeID) {
		try {
			int adminID = adm.getAdminID();

			statement = connect.getConnection().createStatement();
			String adminsql = "INSERT INTO product_table (productName, productType, productAvailibility, productSize, productColor,  productPrice, adminID,typeID) VALUES "
					+ "('"
					+ productName + "','" + productType + "','" + availability + "','" + color + "','" + size + "',"
					+ productPrice + "," + adminID +  "," + productTypeID+ ")";
			System.out.println(adminsql);
			statement.executeUpdate(adminsql);
			System.out.println("Query successfully executed!");	
			statement.close();
		} catch (SQLException e) {
			e.getMessage();
			e.printStackTrace();
			return false;
		}
		return true;//returns true of the execution of query is successful
	}

	//this method executes an sql query to fetch product details from the table
	public List<ProductInfo> fetchProduct() {
		List<ProductInfo> product = new ArrayList<>();
		ResultSet rs = null;
		try {
			int adminID = adm.getAdminID();
			statement = connect.getConnection().createStatement();
			String prosql = "SELECT product_table.productName, product_table.productType, product_table.productAvailibility, product_table.productColor,product_table.productSize,product_table.productPrice,admin_table.adminID "
					+ "FROM product_table, admin_table WHERE product_table.adminID = admin_table.adminID AND admin_table.adminID = "
					+ adminID;
			rs = statement.executeQuery(prosql);
			System.out.println("Query successfully executed!");	

			while (rs.next()) {
				ProductInfo pro = new ProductInfo();
				pro.setProductName(rs.getString(1));
				pro.setProductType(rs.getString(2));
				pro.setProductAvailibility(rs.getString(3));
				pro.setProductColor(rs.getString(4));
				pro.setProductSize(rs.getString(5));
				pro.setProductPrice(rs.getDouble(6));
				product.add(pro);
			}
			statement.close();
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
		// Returns the product object.
		return product;//returns the product  
	}

	//this method executes an sql query to fetch product ID with the help of product name from the table
	public int fetchItemID(String product_name) {
		Connector connect = new Connector();
		Statement statement = null;
		ResultSet rs = null;
		int itemID = 0;
		try {
			statement = connect.getConnection().createStatement();
			String prosql = "SELECT productID FROM product_table WHERE productName ='" + product_name + "'";
			rs = statement.executeQuery(prosql);
			System.out.println("Query successfully executed!");
			while (rs.next()) {
				itemID = rs.getInt(1);
			}
			statement.close();
			rs.close();
		} catch (SQLException e) {
			e.printStackTrace();
			return itemID;
		}
		return itemID;
	}
	//this method executes an sql query to update the product details in the table
	public boolean updateProduct(int proID, String proName, String proType, double proPrice, String proAvailability,
			String proColor, String proSize, int productTypeID) {
		try {
			int adminID = adm.getAdminID();
			//establishing connection with the database
			statement = connect.getConnection().createStatement();
			String prosql = "UPDATE product_table SET productName = '" + proName + "', productType ='" + proType
					+", productPrice =" + proPrice + ", productAvailibility = " + proAvailability + ", productColor = " + proColor + ", productSize = "
					+ proSize +  ",typeID ="+productTypeID+ ",adminID =" + adminID + "WHERE productID = " + proID;

			statement.executeQuery(prosql);
			System.out.println("Product has been updated");
			statement.close();

		} catch (SQLException e) {
			e.getMessage();
			return false;
		}
		return true;//returns true of the execution of query is successful
	}

	//this method executes an sql query to delete a product from the table
	public boolean deleteProduct(int proID) {
		Connector connect = new Connector();
		Statement statement = null;
		try {
			statement = connect.getConnection().createStatement();
			String prosql = "DELETE FROM transaction_table WHERE productID = " + proID;
			statement.executeUpdate(prosql);
			//delete from transaction_table where productID =
			 prosql = "DELETE FROM product_table WHERE productID = " + proID;
			System.out.println(prosql);
			statement.executeUpdate(prosql);
			System.out.println("Selected Product has been deleted");
			statement.close();
		}
		
	
		catch (SQLException e) {
			e.getMessage();
			return false;
		}
		return true;//returns true of the execution of query is successful
	}
}