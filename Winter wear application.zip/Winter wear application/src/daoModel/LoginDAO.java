/**
 * Name : Priyanka Jagadesh Kumar 
 * Source File Name : LoginDAO.java
 * Phase-2: Winter wear Application
 * @author Priyanka Jagadesh Kumar
 * This Dao class contains queries related to Customer and Admin tables  
 * 
 **/
package daoModel;

import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;

import model.AdminDetails;
import model.CustomerDetails;
import model.Login;

//this class validate the credentials entered by the customer and the administrator
public class LoginDAO {
//establishes connection and initializes the result set
	static Connector connect = new Connector();
	private static Statement statement = null;
	ResultSet rs = null;

//this class checks the customer details with the customer table for validation
	public CustomerDetails custDetails(Login login) {
		CustomerDetails cus = new CustomerDetails(); //creates an object for the CustomerDetails.java class

		try {
			statement = connect.getConnection().createStatement();
			//sql query to retrieve the customer username and password from the table
			String cussql = "SELECT * FROM cust_table WHERE cus_loginID = '" + login.getUsername()
					+ "' AND cus_password = '" + login.getPassword() + "'";
			System.out.println(cussql);
			System.out.println("Query successfully executed!");	
			rs = statement.executeQuery(cussql);

			if (rs.next()) {
				cus.setCustomerID(rs.getInt(1));
				cus.setCus_lastname(rs.getString(3));
				cus.setCus_firstname(rs.getString(2));
				cus.setCus_loginID(rs.getString(4));
				cus.setCus_password(rs.getString(5));
				cus.setAddress1(rs.getString(6));
				cus.setAddress2(rs.getString(7));
				cus.setCountry(rs.getString(8));
				cus.setState(rs.getString(9));
				cus.setPinCode(rs.getInt(10));
			} else
				return null;
		} catch (SQLException e) {
			e.getMessage();
		}
		try {
			rs.close();
			statement.close();

		} catch (SQLException e) {
			e.getMessage();
		}
		return cus;//returns the result set
	}
	//this class checks the admin details with the admin table for validation
	public AdminDetails administratorDetails(Login login) {
		AdminDetails cus = new AdminDetails();//creates an object for the AdminDetails.java class
		try {
			statement = connect.getConnection().createStatement();
			//sql query to retrieve the admin username and password from the table
			String admsql = "SELECT * FROM admin_table WHERE adminUsername ='" + login.getUsername()
					+ "' AND password = '" + login.getPassword() + "'";
			rs = statement.executeQuery(admsql);
			System.out.println("Query successfully executed!");
			if (rs.next()) {
				System.out.println("begin...");
				cus.setAdminID(rs.getInt(1));
				cus.setAdmin_lastName(rs.getString(3)); 
				cus.setAdmin_firstName(rs.getString(2));
				cus.setAdmin_loginID(rs.getString(4));
				cus.setAdmin_password(rs.getString(5));

			} else
				return null;
		} catch (SQLException e) {
			e.getMessage();
		}
		try {
			rs.close();
			statement.close();

		} catch (SQLException e) {
			e.getMessage();
		}
		return cus;//returns the result set
	}

}