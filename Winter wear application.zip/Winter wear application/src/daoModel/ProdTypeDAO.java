package daoModel;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import Controller.AdminLoginCont;
import model.AdminDetails;
import model.ProductType;

import java.sql.Statement;
import java.sql.SQLException;

public class ProdTypeDAO implements ProdTypeActivities{
	
	static Connector connect = new Connector();
	static Statement statement = null;

	public List<ProductType> fetchType() {
		List<ProductType> type = new ArrayList<>();
		Connector connect = new Connector();
		Statement statement = null;
		ResultSet rs = null;
		
		
		try {
			
			statement = connect.getConnection().createStatement();
			String typesql = "SELECT typeName FROM producttype_table ORDER BY typeID";
			System.out.println(typesql);
			rs = statement.executeQuery(typesql);
			while (rs.next()) {
				
				ProductType temp_po = new ProductType();
				temp_po.setProdType(rs.getString(1));
				type.add(temp_po);
				
				}
			statement.close();
			rs.close();
		}catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
		return type;
	}
	public List<ProductType> viewProductType(){
		
			List<ProductType> type = new ArrayList<>();
			Connector connect = new Connector();
			Statement statement = null;
			ResultSet rs = null;
			try {
				statement = connect.getConnection().createStatement();
				String typesql = "SELECT typeName FROM producttype_table ORDER BY typeID";
				System.out.println(typesql);
				rs = statement.executeQuery(typesql);
				while (rs.next()) {
					ProductType protyp = new ProductType();
					protyp.setProdType(rs.getString(1));
					type.add(protyp);
					
				}
				statement.close();
				rs.close();
			}
				catch (SQLException e) {
					e.printStackTrace();
					return null;
				}
				return type;
			}
	
	public int fetchTypeID(String typeName) {
		Connector connect = new Connector();
		Statement statement = null;
		ResultSet rs = null;
		int typeID = 0;
		try {
			statement = connect.getConnection().createStatement();
			String typesql = "SELECT typeID FROM producttype_table WHERE typeName ='" + typeName + "'";
			System.out.println(typesql);
			rs = statement.executeQuery(typesql);
			System.out.println("success");
			while (rs.next()) {
				typeID = rs.getInt(1);
				
			}
			statement.close();
			rs.close();
		} 
		catch (SQLException e) {
			e.printStackTrace();
			return typeID;
		}
		return typeID;
	}

	
			public boolean insertProType(String typeName) {
				Connector connect = new Connector();
				Statement statement = null;
				
				try {
					AdminDetails admin = AdminLoginCont.getAdmin();
					int adminID = admin.getAdminID();
					statement = connect.getConnection().createStatement();
					String typesql = "INSERT INTO producttype_table(typeName,adminID) "+"VALUES('"
							+typeName+ "'," +adminID+ ")";
					System.out.println(typesql);
				statement.executeUpdate(typesql);
				System.out.println("executed");
			statement.close();
				}
				catch (SQLException e) {
					e.getMessage();
					e.printStackTrace();
					return false;
				}
				return true;
			}
			
			public boolean updateProType(int typeID, String typeName) {
				Connector connect = new Connector();
				Statement statement = null;
				try {
					AdminDetails admin = AdminLoginCont.getAdmin();
					int adminID = admin.getAdminID();
				statement = connect.getConnection().createStatement();
				String typesql = "UPDATE producttype_table SET typeName = "+typeName+ ",adminID =" +adminID+ "WHERE typeID =" +typeID;
			statement.executeQuery(typesql);
		statement.close();
			}
			catch (SQLException e) {
				e.getMessage();
				return false;
			}
			return true;
		}
			public boolean deleteProType(int typeID) {
				Connector connect = new Connector();
				Statement statement = null;
				try {
				statement = connect.getConnection().createStatement();
				String typesql = "DELETE FROM producttype_table WHERE typeID =" +typeID;
			statement.executeUpdate(typesql);
		 statement.close();
			}
			catch (SQLException e) {
				e.getMessage();
				return false;
			}
			return true;
		}
			
			
			}
				


