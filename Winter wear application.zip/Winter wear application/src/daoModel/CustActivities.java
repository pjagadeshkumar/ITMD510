/**
 * Name : Priyanka Jagadesh Kumar 
 * Source File Name : CustActivities.java
 * Phase-2: Winter wear Application
 * @author Priyanka Jagadesh Kumar
 * This class contains all the customer activities  
 * 
 **/
package daoModel;

import java.util.List;

import model.TransactionDetails;

public interface CustActivities {
//contains the activities for the customer table 
	
	public boolean newCustomer(String cus_lastname, String cus_firstname, String cus_loginID, String cus_password, String address1,
	String address2, String country, String state, int pinCode);//adding a new customer
	
	public boolean updateCustomer(String cus_lastname, String cus_firstname, String cus_loginID, String cus_password, String address1,
			String address2, String country, String state, int pinCode);//updating the customer profile
	
	public boolean createTransaction(String productName, int quantity, double totalPrice, int customerID, int productID);//creates a transaction 
	
	public List<TransactionDetails> fetchTransaction();//fetches list of transactions
}
