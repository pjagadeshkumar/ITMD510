/**
 * Name : Priyanka Jagadesh Kumar 
 * Source File Name : Connector.java
 * Phase-2: Winter wear Application
 * @author Priyanka Jagadesh Kumar
 * This class is used to establish connection with the database application
 * 
 **/
package daoModel;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class Connector {
	
	Connection connect = null;//instantiate the connection
	public Connection getConnection() {
		
	
		try {
			String driver = "com.mysql.jdbc.Driver";//calls the driver for connection
			String url = "jdbc:mysql://www.papademas.net:3306/fp510?autoReconnect=true&useSSL=false";//creates a connection to the database
			String username = "fpuser";
			String password = "510";
			Class.forName(driver);
			connect = DriverManager.getConnection(url, username, password);
			System.out.println("Connected");
			return connect;
		}
		
		catch (SQLException e) { 
			 System.out.println(e.getMessage());
		 }
		 catch (ClassNotFoundException e) {
			e.printStackTrace();
		 
	 }		
		return connect;
	}
}
	


