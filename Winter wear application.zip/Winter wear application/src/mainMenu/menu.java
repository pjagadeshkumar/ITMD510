/**
 * Name : Priyanka Jagadesh Kumar 
 * Source File Name : menu.java
 * Phase-2: Winter wear Application
 * @author Priyanka Jagadesh Kumar
 * This class is used to load the first page of the project which asks the user to select the type of user
 * 
 **/
package mainMenu;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class menu extends Application {
	@Override 
	public void start(Stage primaryStage) {
		try {
			//FXML loads the main function to the view
			Parent rootGroup = FXMLLoader.load(getClass().getResource("/Controller/MainPage.fxml")); //redirects to the MainPage
			Scene scene = new Scene(rootGroup,629,438);
			primaryStage.setTitle("SAVVANA WINTER CLOTHING APPLICATION");
			primaryStage.setScene(scene);
			primaryStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
//Main method for the beginning of the application
	public static void main(String[] args) {
		Application.launch(args);
	}
}
