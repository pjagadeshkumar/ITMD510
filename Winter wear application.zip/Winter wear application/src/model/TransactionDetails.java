/**
 * Name : Priyanka Jagadesh Kumar 
 * Source File Name : TransactionDetails.java
 * Phase-2: Winter wear Application
 * @author Priyanka Jagadesh Kumar
 * This class stores the details of products that are selected by the customer or the administrator
 * 
 **/
package model;

import java.sql.Date;

public class TransactionDetails {
	//table fields declared
	private int transactionID;
	private String productName;
	private int quantity;
	private double totalPrice;
	private Date transactionDate;
	
	//constuctor is set for this class
	public TransactionDetails(int transactionID, String productName, int quantity, double totalPrice, Date transactionDate) {
		// TODO Auto-generated constructor stub
		this.transactionID = transactionID;
		this.productName = productName;
		this.quantity = quantity;
		this.totalPrice = totalPrice;
		this.transactionDate = transactionDate;
	}
	public TransactionDetails() {
		// TODO Auto-generated constructor stub
	}
	//getters and setter are set for each field variables
	public int getTransactionID() {
		return transactionID;
	}
	public void setTransactionID(int transactionID) {
		this.transactionID = transactionID;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public double getTotalPrice() {
		return totalPrice;
	}
	public void setTotalPrice(double totalPrice) {
		this.totalPrice = totalPrice;
	}
	public Date getTransactionDate() {
		return transactionDate;
	}
	public void setTransactionDate(Date transactionDate) {
		this.transactionDate = transactionDate;
	}
}
