/**
 * Name : Priyanka Jagadesh Kumar 
 * Source File Name : ProductType.java
 * Phase-2: Winter wear Application
 * @author Priyanka Jagadesh Kumar
 * This class stores the details of product types
 * 
 **/
package model;

public class ProductType {
	//table fields declared
	private String prodType;

	//constuctor is set for this class
	public ProductType(String prodType ) {
		// TODO Auto-generated constructor stub
		this.prodType = prodType;
	}

	

	public ProductType() {
		// TODO Auto-generated constructor stub
	}



	public String getProdType() {
		return prodType;
	}

	public void setProdType(String prodType) {
		this.prodType = prodType;
	}
	
}
