/**
 * Name : Priyanka Jagadesh Kumar 
 * Source File Name : ProductInfo.java
 * Phase-2: Winter wear Application
 * @author Priyanka Jagadesh Kumar
 * This class stores the details of products
 * 
 **/
package model;

public class ProductInfo {
	//table fields declared
        private int productID;
		private String productName;
		private String productType;
		private String productAvailibility;
		private String productSize;
		private String productColor;
	    private double productPrice;	
		
		
	  //constuctor is set for this class
		public ProductInfo(String productName, String productType, String productAvailibility, String productSize, String productColor,
				double productPrice) {
			// TODO Auto-generated constructor stub
			
			this.productName = productName;
			this.productType = productType;
			this.productAvailibility = productAvailibility;
			this.productSize = productSize;
			this.productColor = productColor;
			this.productPrice = productPrice;
			
		}
		public ProductInfo() {
			// TODO Auto-generated constructor stub
		}
		//getters and setter are set for each field variables
		public String getProductName() {
			return productName;
		}
		public void setProductName(String productName) {
			this.productName = productName;
		}
		public String getProductType() {
			return productType;
		}
		public void setProductType(String productType) {
			this.productType = productType;
		}
		public String getProductAvailibility() {
			return productAvailibility;
		}
		public void setProductAvailibility(String productAvailibility) {
			this.productAvailibility = productAvailibility;
		}
		public String getProductSize() {
			return productSize;
		}
		public void setProductSize(String productSize) {
			this.productSize = productSize;
		}
		public String getProductColor() {
			return productColor;
		}
		public void setProductColor(String productColor) {
			this.productColor = productColor;
		}
		public double getProductPrice() {
			return productPrice;
		}
		public void setProductPrice(double productPrice) {
			this.productPrice = productPrice;
		}
		public int getProductID() {
			return productID;
		}
		public void setProductID(int productID) {
			this.productID = productID;
		}
}