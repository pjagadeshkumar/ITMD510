/**
 * Name : Priyanka Jagadesh Kumar 
 * Source File Name : SelectedProd.java
 * Phase-2: Winter wear Application
 * @author Priyanka Jagadesh Kumar
 * This class stores the details of products that are selected by the customer or the administrator
 * 
 **/
package model;

public class SelectedProd {
	//table fields declared
	//the variables are static because they are called in many instances in the application
	private static int prod_id;
	private static String prod_name;
	private static String prod_type;
	private static double prod_price;
	private static String productAvailibility;
	private static String productSize;
	private static String productColor;
	
	//getters and setter are set for each field variables
	public static int getProd_id() {
		return prod_id;
	}
	public static void setProd_id(int prod_id) {
		SelectedProd.prod_id = prod_id;
	}
	public static String getProd_name() {
		return prod_name;
	}
	public static void setProd_name(String prod_name) {
		SelectedProd.prod_name = prod_name;
	}
	public static String getProd_type() {
		return prod_type;
	}
	public static void setProd_type(String prod_type) {
		SelectedProd.prod_type = prod_type;
	}
	public static double getProd_price() {
		return prod_price;
	}
	public static void setProd_price(double prod_price) {
		SelectedProd.prod_price = prod_price;
	}
	public static String getProductAvailibility() {
		return productAvailibility;
	}
	public static void setProductAvailibility(String productAvailibility) {
		SelectedProd.productAvailibility = productAvailibility;
	}
	public static String getProductSize() {
		return productSize;
	}
	public static void setProductSize(String productSize) {
		SelectedProd.productSize = productSize;
	}
	public static String getProductColor() {
		return productColor;
	}
	public static void setProductColor(String productColor) {
		SelectedProd.productColor = productColor;
	}}
	