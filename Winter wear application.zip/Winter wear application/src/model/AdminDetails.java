/**
 * Name : Priyanka Jagadesh Kumar 
 * Source File Name : AdminDetails.java
 * Phase-2: Winter wear Application
 * @author Priyanka Jagadesh Kumar
 * This class stores the details of administrator
 * 
 **/
package model;

public class AdminDetails {
//table fields declared
	private int adminID;
	private String admin_lastName;
	private String admin_firstName;
	private String admin_loginID;
	private String admin_password;
	
	//getters and setter are set for each field variables
	public int getAdminID() {
		return adminID;
	}
	public void setAdminID(int adminID) {
		this.adminID = adminID;
	}
	public String getAdmin_lastName() {
		return admin_lastName;
	}
	public void setAdmin_lastName(String admin_lastName) {
		this.admin_lastName = admin_lastName;
	}
	public String getAdmin_firstName() {
		return admin_firstName;
	}
	public void setAdmin_firstName(String admin_firstName) {
		this.admin_firstName = admin_firstName;
	}
	public String getAdmin_loginID() {
		return admin_loginID;
	}
	public void setAdmin_loginID(String admin_loginID) {
		this.admin_loginID = admin_loginID;
	}
	public String getAdmin_password() {
		return admin_password;
	}
	public void setAdmin_password(String admin_password) {
		this.admin_password = admin_password;
	}
}
