/**
 * Name : Priyanka Jagadesh Kumar 
 * Source File Name : SelectedProdType.java
 * Phase-2: Winter wear Application
 * @author Priyanka Jagadesh Kumar
 * This class stores the details of product types that are selected by the customer or the administrator
 * 
 **/
package model;

public class SelectedProdType {
	//table fields declared
	//the variables are static because they are called in many instances in the application
	private static int typeID;
	private static String typename;
	
	//getters and setter are set for each field variables
	public static int getTypeID() {
		return typeID;
	}
	public void setTypeID(int typeID) {
		SelectedProdType.typeID = typeID;
	}
	public static String getTypename() {
		return typename;
	}
	public void setTypename(String typename) {
		SelectedProdType.typename = typename;
	}
	
}
