/**
 * Name : Priyanka Jagadesh Kumar 
 * Source File Name : CustomerDetails.java
 * Phase-2: Winter wear Application
 * @author Priyanka Jagadesh Kumar
 * This class stores the details of customer
 * 
 **/
package model;

public class CustomerDetails {
	//table fields declared
	private int customerID;
	private String cus_lastname;
	private String cus_firstname;
	private String cus_loginID;
	private String cus_password;
	private String address1;
	private String address2;
	private String country;
	private String state;
	private int pinCode;
	
	//getters and setter are set for each field variables
	public int getCustomerID() {
		return customerID;
	}
	public void setCustomerID(int customerID) {
		this.customerID = customerID;
	}
	public String getCus_lastname() {
		return cus_lastname;
	}
	public void setCus_lastname(String cus_lastname) {
		this.cus_lastname = cus_lastname;
	}
	public String getCus_firstname() {
		return cus_firstname;
	}
	public void setCus_firstname(String cus_firstname) {
		this.cus_firstname = cus_firstname;
	}
	public String getCus_loginID() {
		return cus_loginID;
	}
	public void setCus_loginID(String cus_loginID) {
		this.cus_loginID = cus_loginID;
	}
	public String getCus_password() {
		return cus_password;
	}
	public void setCus_password(String cus_password) {
		this.cus_password = cus_password;
	}
	public String getAddress1() {
		return address1;
	}
	public void setAddress1(String address1) {
		this.address1 = address1;
	}
	public String getAddress2() {
		return address2;
	}
	public void setAddress2(String address2) {
		this.address2 = address2;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public int getPinCode() {
		return pinCode;
	}
	public void setPinCode(int pinCode) {
		this.pinCode = pinCode;
	}
	

}
