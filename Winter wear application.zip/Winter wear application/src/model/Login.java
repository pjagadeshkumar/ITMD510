/**
 * Name : Priyanka Jagadesh Kumar 
 * Source File Name : Login.java
 * Phase-2: Winter wear Application
 * @author Priyanka Jagadesh Kumar
 * This class stores the login fields required to validate the user
 * 
 **/
package model;

public class Login {
	// fields declared
	private String username;
	private String password;
	
	//getters and setter are set for each field variables
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
}
