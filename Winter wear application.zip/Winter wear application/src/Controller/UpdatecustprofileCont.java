/**
 * Name : Priyanka Jagadesh Kumar 
 * Source File Name :UpdatecustprofileCont.java
 * Phase-2: Winter wear Application
 * @author Priyanka Jagadesh Kumar
 * This class allows the user to update his/her profile 
 * 
 **/
package Controller;

import java.awt.Dimension;

import javax.swing.JOptionPane;
import javax.swing.JTextPane;

import daoModel.CustDAO;
import javafx.event.*;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import model.CustomerDetails;

public class UpdatecustprofileCont {
//declaring the FXML components
	@FXML
	private TextField custfname;
	@FXML
	private TextField custlName;
	@FXML
	private TextField custusername;
	@FXML
	private PasswordField custpassword;
	@FXML
	private TextField custaddressOne;
	@FXML
	private TextField custaddressTwo;
	@FXML
	private TextField custcountry;
	@FXML
	private TextField custstate;
	@FXML
	private TextField custpostalCode;
	@FXML
	private Label message;

	Parent root;
	Stage stageuser;
	
	CustDAO custDAO = new CustDAO();//creates an object for the CustDAO.java class
	CustomerDetails cust = CustLoginCont.getCustomer();//creates an object for the CustomerDetails.java class
	
	@FXML
	void initialize() {
//This methods populates the fields automatically when the update customer profile button is clicked
		System.out.println("Update button is clicked...");
		String pin = Integer.toString(cust.getPinCode());
		System.out.println();
		custfname.setText(cust.getCus_firstname());
		System.out.println(custfname.getText());
		custlName.setText(cust.getCus_lastname());
		custusername.setText(cust.getCus_loginID());
		custpassword.setText(cust.getCus_password());
		custaddressOne.setText(cust.getAddress1());
		custaddressTwo.setText(cust.getAddress2());
		custcountry.setText(cust.getCountry());
		custstate.setText(cust.getState());
		custpostalCode.setText(pin);

	}
//this method is called when customer wishes to log out
	public void custLogout(ActionEvent a) {
		System.out.println("logout button is clicked...");
		try {
			//redirects to the customer login page page
			Parent rootGroup = FXMLLoader.load(getClass().getResource("/Controller/CustLoginPage.fxml"));
    		Scene scene = new Scene(rootGroup,629,438);
			stageuser = (Stage) ((Node) a.getSource()).getScene().getWindow();

    		stageuser.setScene(scene);
    		stageuser.show();
		} catch (Exception e) {
			e.getMessage();
		}
	}
//this method is called when customer wishes to go back to previous page
	public void goback(ActionEvent a) {
		System.out.println("Back button is clicked...");
		try {
			//redirects to the customer home page page
			Parent rootGroup = FXMLLoader.load(getClass().getResource("/Controller/CustHomePage.fxml"));
    		Scene scene = new Scene(rootGroup,629,438);
			stageuser = (Stage) ((Node) a.getSource()).getScene().getWindow();

    		stageuser.setScene(scene);
    		stageuser.show();
		} catch (Exception e) {
			e.getMessage();
		}
	}

	public void updateCustomer(ActionEvent a) {
		System.out.println("Update button is clicked...");
		// Fetching the input values.
		String fname = custfname.getText();
		String lname = custlName.getText();
		String username = custusername.getText();
		String password = custpassword.getText();
		String addressone = custaddressOne.getText();
		String addresstwo = custaddressTwo.getText();
		String Country = custcountry.getText();
		String State = custstate.getText();
		String zipCode = custpostalCode.getText();

		if (fname.isEmpty())
			message.setText("Enter your first name");
		else if (lname.isEmpty())
			message.setText("Enter your last name");
		else if (username.isEmpty())
			message.setText("Enter the username");
		else if (password.isEmpty())
			message.setText("Enter the password");
		else if (addressone.isEmpty())
			message.setText("Enter your Address Line 1");
		else if (addresstwo.isEmpty())
			message.setText("Enter your Address Line 2");
		else if (Country.isEmpty())
			message.setText("Enter the country name");
		else if (State.isEmpty())
			message.setText("Enter the state");
		else if (zipCode.isEmpty())
			message.setText("Enter the zipcode");
		else {
			try {
				Integer cuszip = Integer.parseInt(zipCode);
				//query updates the modified customer details in the customer table
				boolean update = custDAO.updateCustomer(fname, lname, username, password, addressone, addresstwo, Country, State, cuszip);
				if (update) {
					System.out.println("updated");
					JTextPane tp = new JTextPane();
					tp.setSize(new Dimension(500, 20));
					tp.setPreferredSize(new Dimension(500, tp.getPreferredSize().height));
					JOptionPane.showMessageDialog(null, "Updated!");
					try {
						//redirects to the customer home page page
						Parent rootGroup = FXMLLoader.load(getClass().getResource("/Controller/CustHomePage.fxml"));
			    		Scene scene = new Scene(rootGroup,629,438);
						stageuser = (Stage) ((Node) a.getSource()).getScene().getWindow();

			    		stageuser.setScene(scene);
			    		stageuser.show();
					} catch (Exception e) {
						e.getMessage();
					}
				} 
				else
				message.setText("Problem occured when updating..");
			} catch (NumberFormatException e) {
				message.setText("Enter the valid input");
				e.getMessage();
			}
		}

	}


}
