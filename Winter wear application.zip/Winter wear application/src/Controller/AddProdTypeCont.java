/**
 * Name : Priyanka Jagadesh Kumar 
 * Source File Name : AddProdTypeCont.java
 * Phase-2: Winter wear Application
 * @author Priyanka Jagadesh Kumar
 * This class is used to add a product type by the administrator
 * 
 **/
package Controller;

import java.awt.Dimension;

import javax.swing.JOptionPane;
import javax.swing.JTextPane;

import Controller.AdminLoginCont;
import daoModel.ProdTypeDAO;
import javafx.event.*;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class AddProdTypeCont {
	//initiating the fields using FXML
	@FXML
	private TextField typeName;
	@FXML
	private Label message;
	

	Parent root;
	Stage stageuser;
	
	ProdTypeDAO protype = new ProdTypeDAO();//object creation for ProductTypeDAO.java class
	
	
	// This method is called when the admin clicks the submit button after entering all the details for the product type
	public void addProductType(ActionEvent a) {
		System.out.println("Adding product type..");
		//getting the input values from the respective classes
		String prodType = typeName.getText();
		System.out.println(prodType);
		if (prodType == null || prodType.isEmpty())
			message.setText("Enter the Product Type name");
		else {
			boolean created = protype.insertProType(prodType);
			if(created) {
				//message.setText("New product Type is created!");
				System.out.println("The product type is created");
				typeName.clear();//clears the text-boxes after the submit button is clicked
				JTextPane tp = new JTextPane();
				tp.setSize(new Dimension(500, 20));
				tp.setPreferredSize(new Dimension(500, tp.getPreferredSize().height));
				JOptionPane.showMessageDialog(null, "Product type is created!");
			}
			else
				message.setText("Error occurred while creating a product table");
		}
	}//This method is called when the admin clicks back button and wants to go back to the admin home page 
		public void goback(ActionEvent a){
			try {
				Parent rootGroup = FXMLLoader.load(getClass().getResource("/Controller/AdminHomePage.fxml"));
				Scene scene = new Scene(rootGroup, 629, 438);
				stageuser = (Stage) ((Node) a.getSource()).getScene().getWindow();

				stageuser.setScene(scene);
				stageuser.show();
			} catch (Exception e) {
				e.getMessage();
			}
		}
		//This method is called when the admin wishes to logout from his/her account. The logout button is clicked
			public void prodTypeLogout(ActionEvent a) {
				AdminLoginCont.adminLogout();
				try
				{
					Parent rootGroup = FXMLLoader.load(getClass().getResource("/Controller/AdminLogin.fxml"));
					Scene scene = new Scene(rootGroup, 629, 438);
					stageuser = (Stage) ((Node) a.getSource()).getScene().getWindow();

					stageuser.setScene(scene);
					stageuser.show();
				} catch (Exception e) {
					e.getMessage();
				}
				}
				
			}

			
	

