/**
 * Name : Priyanka Jagadesh Kumar 
 * Source File Name : customerSwitch.java
 * Phase-2: Winter wear Application
 * @author Priyanka Jagadesh Kumar
 * This class is used to redirect to customer home page 
 * where the user can perform different functions 
 **/
package Controller;
import javafx.collections.FXCollections;
import javafx.event.*;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.stage.Stage;
import model.CustomerDetails;
//import model.ProductInfo;
import java.io.IOException;
import java.util.List;
import Controller.CustLoginCont;
import Controller.ViewTransacCont;
//import Controller.BuyProductCont;
import daoModel.CustDAO;
import daoModel.ProductinfoDAO;
import model.TransactionDetails;
//This class extends the details of the customer

public class customerSwitch extends CustomerDetails {

		Label welcome;
		Parent root;
		Stage stageuser;
		ProductinfoDAO prod = new ProductinfoDAO();
		CustDAO cust = new CustDAO();
		CustomerDetails customer = CustLoginCont.getCustomer();
		//initialization function prints the welcome customer text
		void init() {
			welcome.setText("Welcome to Savvana Winter Shopping Application, " + customer.getCus_firstname());
		}
		//This method allows the customer to update his/her profile with the click of update profile button 
			public void updateCustomerProfile(ActionEvent a) {
				System.out.println("Update profile button is clicked...");
				try {
					//redirects to the add update customer profile page
					Parent rootGroup = FXMLLoader.load(getClass().getResource("/Controller/UpdateCustProfile.fxml"));
		    		Scene scene = new Scene(rootGroup,629,438);
					stageuser = (Stage) ((Node) a.getSource()).getScene().getWindow();
		    		stageuser.setScene(scene);
		    		stageuser.show();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
				public void viewTransaction(ActionEvent a) {
					System.out.println("View transaction button is clicked...");
					try {
						//redirects to the view transaction page
						FXMLLoader loader = new FXMLLoader(getClass().getResource("/Controller/ViewTransaction.fxml"));
						root = loader.load();
						Scene scene = new Scene(root,629,438);
						stageuser = (Stage) ((Node) a.getSource()).getScene().getWindow();
			    		stageuser.setScene(scene);
						ViewTransacCont controller = loader.getController();
						List<TransactionDetails> tra;
						// all the products in the transaction table is added to the array
						tra = cust.fetchTransaction();
						// Passes transaction list to populateData() method in ViewTransactionController class.
						controller.populateData(FXCollections.observableArrayList(tra));
						stageuser.show();
					} catch (Exception e) {
						e.getMessage();
					}
				}
				public void buyProducts(ActionEvent a) {
					System.out.println("Buy products button is clicked...");
					
						try {		
							//redirects to the buy product page
							Parent rootGroup = FXMLLoader.load(getClass().getResource("/Controller/BuyProduct.fxml"));
							System.out.println("start");
							Scene scene = new Scene(rootGroup, 629, 438);
							stageuser = (Stage) ((Node) a.getSource()).getScene().getWindow();
							stageuser.setScene(scene);
							stageuser.show();
						} catch (Exception e) {
							e.getMessage();
						}
				}
				public void logoutCustomer(ActionEvent a) {
					System.out.println("Logout button is clicked...");
					try {
						//redirects to the customer login page
						Parent rootGroup = FXMLLoader.load(getClass().getResource("/Controller/CustLoginPage.fxml"));
			    		Scene scene = new Scene(rootGroup,629,438);
						stageuser = (Stage) ((Node) a.getSource()).getScene().getWindow();
			    		stageuser.setScene(scene);
			    		stageuser.show();
					} catch (Exception e) {
						e.getMessage();
					}
			}
		}
	
