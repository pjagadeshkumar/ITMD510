/**
 * Name : Priyanka Jagadesh Kumar 
 * Source File Name : BuyProductCont.java
 * Phase-2: Winter wear Application
 * @author Priyanka Jagadesh Kumar
 * This class is used to redirect the customer to buy product screen when the buy product button is clicked 
 * where the customer can buy products
 **/
package Controller;

import java.awt.Label;
import java.net.URL;

import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ResourceBundle;

import daoModel.Connector;
import daoModel.ProductinfoDAO;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.*;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import model.ProductInfo;
import model.SelectedProd;
//this class implements the initializable method to implement the initialize methods in the class 
public class BuyProductCont implements Initializable{
	//establishing connection and initializing the result set
	static Connector connect = new Connector();
	static Statement statement = null;
	ResultSet rs = null;
	//declaring table view and column variables
	@FXML
	private TableView<ProductInfo> prod;
	
	@FXML
    private TableColumn<?, ?> fxnameCol1;

    @FXML
    private TableColumn<?, ?> fxtypeCol1;

    @FXML
    private TableColumn<?, ?> fxavailCol1;

    @FXML
    private TableColumn<?, ?> fxpriceCol1;

    @FXML
    private TableColumn<?, ?> fxclrCol1;

    @FXML
    private TableColumn<?, ?> fxsizeCol1;
    
    @FXML
	private ObservableList<ProductInfo> product;
	
	@FXML
	private Label error;
	
	ProductinfoDAO prodao = new ProductinfoDAO();//creates an object for ProductinfoDAO.java class
	Parent root;
	Stage stageuser;
	
	//this method is called when a customer wishes to place order by selecting the products he wants to purchase
	public void placeOrder(ActionEvent a) {
		try {
			System.out.println("The place Order button is clicked...");
		ProductInfo product = prod.getSelectionModel().getSelectedItem();
		if (product == null)
			error.setText("Select the Product");
		
		String productName = product.getProductName();
		String productType = product.getProductType();
		String prodAvail = product.getProductAvailibility();
		String prodSize = product.getProductSize();
		String prodColor = product.getProductColor();
		double productPrice = product.getProductPrice();
		int productID = prodao.fetchItemID(productName);
		
		SelectedProd.setProd_id(productID);
		SelectedProd.setProd_name(productName);
		SelectedProd.setProd_type(productType);
		SelectedProd.setProductAvailibility(prodAvail);
		SelectedProd.setProductSize(prodSize);
		SelectedProd.setProductColor(prodColor);
		SelectedProd.setProd_price(productPrice);
		
		System.out.println("The selected items are added to the selected product class!");
		//redirects to the order place class after the customer selects all the products he wishes to buy
		Parent rootGroup = FXMLLoader.load(getClass().getResource("/Controller/OrderPlace.fxml"));
		Scene scene = new Scene(rootGroup, 629, 438);
		stageuser = (Stage) ((Node) a.getSource()).getScene().getWindow();
		stageuser.setScene(scene);
		stageuser.show();
		}
		catch (Exception e) {
			e.getMessage();
		}
	}
	//this method is called when the user wishes to go to previous screen
		public void gobackback(ActionEvent a){
			System.out.println("The go back button is clicked...");
			try {
				Parent rootGroup = FXMLLoader.load(getClass().getResource("/Controller/CustHomePage.fxml"));
				Scene scene = new Scene(rootGroup, 629, 438);
				stageuser = (Stage) ((Node) a.getSource()).getScene().getWindow();

				stageuser.setScene(scene);
				stageuser.show();
			} catch (Exception e) {
				e.getMessage();
			}
	}
		//This method is called when the customer wishes to logout from his/her account. The logout button is clicked
		public void buycusLogout(ActionEvent a) {
			System.out.println("The logout button is clicked...");
			try {
				Parent rootGroup = FXMLLoader.load(getClass().getResource("/Controller/CustLoginPage.fxml"));
				Scene scene = new Scene(rootGroup, 629, 438);
				stageuser = (Stage) ((Node) a.getSource()).getScene().getWindow();

				stageuser.setScene(scene);
				stageuser.show();
			} catch (Exception e) {
				e.getMessage();
			}
			}
//this method connects the column variables to the table fields
		@Override
		public void initialize(URL location, ResourceBundle resources) {
			// TODO Auto-generated method stub
			//System.out.println("in initializable");
			fxnameCol1.setCellValueFactory(new PropertyValueFactory<>("productName"));
			fxtypeCol1.setCellValueFactory(new PropertyValueFactory<>("productType"));
			fxavailCol1.setCellValueFactory(new PropertyValueFactory<>("productAvailibility"));
			fxpriceCol1.setCellValueFactory(new PropertyValueFactory<>("productPrice"));
			fxclrCol1.setCellValueFactory(new PropertyValueFactory<>("productColor"));
			fxsizeCol1.setCellValueFactory(new PropertyValueFactory<>("productSize"));
			//an array is initialized where the products are stored
			ObservableList<ProductInfo> product = FXCollections.observableArrayList();
			
			try {
				//establishing connection
				statement = connect.getConnection().createStatement();
				//selects the columns from the product type table
				String sqlprod = "Select productName,productType,productAvailibility,productSize,productColor,productPrice from product_table";
			
				rs = statement.executeQuery(sqlprod);

				while (rs.next()) {
					product.add(new ProductInfo(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getDouble(6)));
			
					prod.setItems(product);
					
				}
				System.out.println("populated!");
				statement.close();
			} catch (Exception e) {
				e.getMessage();
				e.printStackTrace();
			}

		}
			
		}

		

		

