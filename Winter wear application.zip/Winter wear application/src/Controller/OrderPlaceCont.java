/**
 * Name : Priyanka Jagadesh Kumar 
 * Source File Name : OrderPlaceCont.java
 * Phase-2: Winter wear Application
 * @author Priyanka Jagadesh Kumar
 * This class is called when the user wants to place order on the 
 * selected items
 **/
package Controller;

import java.awt.Dimension;
import java.text.DecimalFormat;

import javax.swing.JOptionPane;
import javax.swing.JTextPane;

import javafx.scene.input.KeyEvent;

import daoModel.CustDAO;
import daoModel.ProductinfoDAO;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import model.CustomerDetails;
import model.SelectedProd;

//This method extends the selected product class
public class OrderPlaceCont extends SelectedProd{
	//declaring variables for the FXML components
	@FXML
	private TextField prod_name;
	@FXML
	private TextField prod_quantity;
	@FXML
	private TextField prod_price;
	@FXML
	private Label message;

	Parent root;
	Stage stage;
	
	CustDAO cusdao = new CustDAO();//creates an object for the CustDAO.java object
	ProductinfoDAO prodao = new ProductinfoDAO();//creates an object for the ProductinfoDAO.java object
	
//this method is called to populate the name of the product and initial price in their respective fields
	@FXML
	void initialize() {
		String price = Double.toString(getProd_price());
		prod_name.setText(getProd_name());
		prod_price.setText(price);
	}
	
	//this method calculates the total price of the items selected by the customer depending on the the number of quantity and populates the total in the price textbox
	@FXML
	public void TotalPrice(KeyEvent a) {
	try {
		double productPrice = getProd_price();
		String quant = prod_quantity.getText();
		int prodquant = Integer.parseInt(quant);
		
		if (prodquant == 0) {
			prod_price.setText(Double.toString(productPrice));
			message.setText("Quantity cannot be zero");
		} else {
			DecimalFormat df = new DecimalFormat("#,###,##0.00"); //stores in decimal format
			double totalPrice = prodquant * productPrice; //calculates the total price
			String total = df.format(totalPrice);
			prod_price.setText(total);
		}

	} catch (NumberFormatException e) {
	}
	}
	
	public void PlaceOrdergo(ActionEvent a) {
		System.out.println("Place order button is clicked...");
		String proQuantity = this.prod_quantity.getText();
		String proName = this.prod_name.getText();
		String proPrice = this.prod_price.getText();

		try {
			if (proQuantity.isEmpty() || proQuantity == null)
				message.setText("Enter the Quantity:");
			else {
				CustomerDetails cus = new CustomerDetails();//creates an object for the CustomerDetails.java class
				int quantity = Integer.parseInt(proQuantity);
				double price = Double.parseDouble(proPrice);
				int productID = prodao.fetchItemID(proName); //fetches the product ID using the product Name
				int custID = cus.getCustomerID();
				//inserts the purchased products and its details to the transaction table 
				boolean purchase = cusdao.createTransaction(proName, quantity, price, custID,productID);
				if (purchase) {
					System.out.println("Inserted!");
					JTextPane tp = new JTextPane();
					tp.setSize(new Dimension(500, 20));
					tp.setPreferredSize(new Dimension(500, tp.getPreferredSize().height));
					JOptionPane.showMessageDialog(null, "Product is inserted!");
					
					try
					{
						//redirects to the customer home page using the FX loader
						root = FXMLLoader.load(getClass().getResource("/Controller/CustHomePage.fxml"));
						stage = (Stage) ((Node) a.getSource()).getScene().getWindow();
						stage.setTitle("Administrator Home Page");
						stage.setScene(new Scene(root));
						stage.show();
					
				 }catch (Exception e) {
						e.getMessage();
					}
			}
				else
					message.setText("Problem in creating a new Product");
			}
	}
		catch (Exception e) {
			e.getMessage();
		}

	}
	//this method allows user to go to the previous page
	public void gobacktobuy(ActionEvent a){
		System.out.println("Back button is clicked...");
		try {
			//redirects to the customer home page using the FX loader
			root = FXMLLoader.load(getClass().getResource("/Controller/CustHomePage.fxml"));
			stage = (Stage) ((Node) a.getSource()).getScene().getWindow();
			stage.setTitle("Administrator Home Page");
			stage.setScene(new Scene(root));
			stage.show();
		} catch (Exception e) {
			e.getMessage();
		}
	}
	//this method allows user to log out of their account
		public void prodTypeLogout(ActionEvent a) {
			System.out.println("Logout button is clicked...");
			AdminLoginCont.adminLogout();
			try
			{
				//redirects to the customer Login page using the FX loader
				root = FXMLLoader.load(getClass().getResource("/Controller/CustLoginPage.fxml"));
				stage = (Stage) ((Node) a.getSource()).getScene().getWindow();
				stage.setTitle("Administrator Login Page");
				stage.setScene(new Scene(root));
				stage.show();
			} catch (Exception e) {
				e.getMessage();
			}
			}
	}
