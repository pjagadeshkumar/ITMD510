/**
 * Name : Priyanka Jagadesh Kumar 
 * Source File Name : CustLoginCont.java
 * Phase-2: Winter wear Application
 * @author Priyanka Jagadesh Kumar
 * This class is used to redirect to the customer login page where the customer enters his/her login credentials 
 * and directs to the customer home page
 **/
package Controller;

import java.io.IOException;


import daoModel.LoginDAO;
import javafx.event.*;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.*;
import javafx.stage.Stage;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import model.Login;
import model.CustomerDetails;

//controller for the customer login page
public class CustLoginCont {
	//declaring the FXML variables
	private static CustomerDetails customer;
	@FXML
	private TextField user;	

	@FXML
	private PasswordField password;
    
    @FXML
    private Label error;

    Parent root;
    Stage stageuser;
    Login log = new Login();
    LoginDAO logdao = new LoginDAO();
    
    
    public void newuserRegistration(ActionEvent a) {
    	System.out.println("Register button is clicked...");
    	try {
    		//redirects to the register new customer controller using Fx
    		Parent rootGroup = FXMLLoader.load(getClass().getResource("/Controller/CustRegistration.fxml"));
    		Scene scene = new Scene(rootGroup,629,438);
			stageuser = (Stage) ((Node) a.getSource()).getScene().getWindow();
            stageuser.setScene(scene);
    		stageuser.show();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    }
    //this method is called to validate the login credentials 
    public void signupvalidation(ActionEvent a) {
    	System.out.println("Enter the login details:");
    	
    	CustomerDetails cd = new  CustomerDetails();//object is created for the CustomerDetails.java class
    	//gets the userid and password from the customer table
    	String cus_loginID = user.getText();
    	String cus_password = password.getText();
    	
    	if(cus_loginID.isEmpty() || cus_loginID == null)
    		error.setText("Enter username");
    	else if(cus_password.isEmpty() || cus_password == null)
    		error.setText("Enter password");
    	else 
    	{
    	 log.setUsername(cus_loginID);
    	 log.setPassword(cus_password);
    	
    	cd = logdao.custDetails(log);
    	if (cd.getCus_loginID().equals(cus_loginID) && cd.getCus_password().equals(cus_password)) {
    		customer = cd;
    		try {
    			//redirects to the Customer home page after the validation 
    			Parent rootGroup = FXMLLoader.load(getClass().getResource("/Controller/CustHomePage.fxml"));
    			
    			Scene scene = new Scene(rootGroup,629,438);
    			stageuser = (Stage) ((Node) a.getSource()).getScene().getWindow();
        		stageuser.setScene(scene);
        		stageuser.show();
			} catch (Exception e) {
				e.printStackTrace();
			}
    		
    	}
    	else
			System.out.println("Please enter valid username and password");
    }
    }
    //redirects to the main page using Fx
public void gobacktooptions(ActionEvent a) {
	System.out.println("Back button is clicked...");
	try {
		Parent rootGroup = FXMLLoader.load(getClass().getResource("/Controller/MainPage.fxml"));
		Scene scene = new Scene(rootGroup, 629, 438);
		stageuser = (Stage) ((Node) a.getSource()).getScene().getWindow();

		stageuser.setScene(scene);
		stageuser.show();
	} catch (Exception e) {
		e.printStackTrace();
	}
	
}
public static CustomerDetails getCustomer() {
	return customer;
}

public static void customerLogout() {
	customer = null;
}
}