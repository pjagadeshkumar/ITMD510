/**
 * Name : Priyanka Jagadesh Kumar 
 * Source File Name : AdminSwitch.java
 * Phase-2: Winter wear Application
 * @author Priyanka Jagadesh Kumar
 * This class is used to redirect to admin home page 
 * where the user can perform different functions 
 **/
package Controller;


import daoModel.ProdTypeDAO;
import daoModel.ProductinfoDAO;
//import javafx.collections.FXCollections;
import javafx.event.*;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.stage.Stage;
import model.AdminDetails;
//import model.ProductInfo;
//import model.ProductType;

import Controller.AdminLoginCont;
//import Controller.ViewProdCont;
//import Controller.ViewProdTypeCont;

//This class extends the details of the admin
public class AdminSwitch extends AdminDetails{
	Label welcome;
	Parent root;
	Stage stageuser;
	ProductinfoDAO prod = new ProductinfoDAO();
	ProdTypeDAO protype = new ProdTypeDAO();
	
	AdminDetails admin = AdminLoginCont.getAdmin();
//initialization function prints the welcome admin text
	void init() {
		welcome.setText("Welcome to Savvana Winter Shopping Application, " + admin.getAdmin_firstName());
	}
	
//This method allows the admin to add new products to the products table with the click of add product button 
	public void addProduct(ActionEvent a) {
		System.out.println("Add product button is clicked...");
		//redirects to the add product controller using Fx
		try {
			//redirects to the add product page
			Parent rootGroup = FXMLLoader.load(getClass().getResource("/Controller/AddProduct.fxml"));
			Scene scene = new Scene(rootGroup, 629, 438);
			stageuser = (Stage) ((Node) a.getSource()).getScene().getWindow();

			stageuser.setScene(scene);
			stageuser.show();
		} catch (Exception e) {
			e.getMessage();
		}
	}
//redirects to the view products controller using Fx
	public void viewProduct(ActionEvent a) {
		System.out.println("View product button is clicked...");
		try {
			//redirects to the view product page
			Parent rootGroup = FXMLLoader.load(getClass().getResource("/Controller/ViewProduct.fxml"));
			Scene scene = new Scene(rootGroup, 629, 438);
			stageuser = (Stage) ((Node) a.getSource()).getScene().getWindow();

			stageuser.setScene(scene);
			stageuser.show();
		} catch (Exception e) {
			e.getMessage();
		}
	}
	//redirects to the add product type controller using Fx
	public void addProductType(ActionEvent a) {
		System.out.println("Add product button is clicked...");
		try {
			//redirects to the add product type page
			Parent rootGroup = FXMLLoader.load(getClass().getResource("/Controller/AddProductType.fxml"));
			Scene scene = new Scene(rootGroup, 629, 438);
			stageuser = (Stage) ((Node) a.getSource()).getScene().getWindow();

			stageuser.setScene(scene);
			stageuser.show();
		} catch (Exception e) {
			e.getMessage();
		}
	}
	//redirects to the add product type controller using Fx
	public void viewProductType(ActionEvent a) {
		System.out.println("View product button is clicked...");
		try {
			//redirects to the view product type page
			Parent rootGroup = FXMLLoader.load(getClass().getResource("/Controller/ViewProductType.fxml"));
			System.out.println("wow");
		Scene scene = new Scene(rootGroup, 629, 438);
		stageuser = (Stage) ((Node) a.getSource()).getScene().getWindow();

		stageuser.setScene(scene);
		stageuser.show();
		
		} catch (Exception e) {
			e.getMessage();
		}
	}
//This method is called when the admin wishes to logout from his/her account. The logout button is clicked
	public void logoutAdmin(ActionEvent a) {
		System.out.println("Logout button is clicked...");
		try {
			//redirects to the admin login page
			Parent rootGroup = FXMLLoader.load(getClass().getResource("/Controller/AdminLogin.fxml"));
			Scene scene = new Scene(rootGroup, 629, 438);
			stageuser = (Stage) ((Node) a.getSource()).getScene().getWindow();

			stageuser.setScene(scene);
			stageuser.show();
		} catch (Exception e) {
			e.getMessage();
		}
	}
}
