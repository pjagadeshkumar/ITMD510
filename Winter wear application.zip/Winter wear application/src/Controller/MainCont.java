/**
 * Name : Priyanka Jagadesh Kumar 
 * Source File Name : MainCont.java
 * Phase-2: Winter wear Application
 * @author Priyanka Jagadesh Kumar
 * This class called when the user wishes to choose the type of user 
 * and then redirected to respective login pages
 **/
package Controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
//import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
//import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class MainCont {

	Parent root;
	Stage stage;
	
	// If the user is administrator, then he is redirected to Admin login screen.
	public void adminPage(ActionEvent a) {
		System.out.println("Administrator button is clicked...");
		try {
			//redirects to admin login page
			root = FXMLLoader.load(getClass().getResource("/Controller/AdminLogin.fxml"));
			stage = (Stage) ((Node) a.getSource()).getScene().getWindow();
			stage.setTitle("Administrator Login");
			stage.setScene(new Scene(root));
			stage.show();
		} catch (Exception e) {
			e.getMessage();
		}

	}

	// If the user is Customer, then he is redirected to Customer login screen.
	public void customerPage(ActionEvent a) {
		System.out.println("Customer button is clicked...");
		try {
			//redirects to customer login page
			root = FXMLLoader.load(getClass().getResource("/Controller/CustLoginPage.fxml"));
			stage = (Stage) ((Node) a.getSource()).getScene().getWindow();
			stage.setTitle("Customer Login");
			stage.setScene(new Scene(root));
			stage.show();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	}
	
