/**
 * Name : Priyanka Jagadesh Kumar 
 * Source File Name : ViewProdTypeCont.java
 * Phase-2: Winter wear Application
 * @author Priyanka Jagadesh Kumar
 * This class is called when the user wants to view the products types available  
 * in the list
 **/
package Controller;
import java.awt.Dimension;
import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ResourceBundle;

import javax.swing.JOptionPane;
	import javax.swing.JTextPane;

import daoModel.Connector;
import daoModel.ProdTypeDAO;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
	import javafx.event.*;
	import javafx.fxml.FXML;
	import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
	import javafx.scene.Parent;
	import javafx.scene.Scene;
	import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import model.ProductInfo;
import model.ProductType;

import model.SelectedProdType;

//this class implements initializable method
public class ViewProdTypeCont implements Initializable{
	//connection is established and the result set in initialized
	static Connector connect = new Connector();
	static Connection conn;
	static Statement statement = null;
	ResultSet rs = null;
	//FXML variables are declared
		@FXML
		private TableView<ProductType> prods; //table view is declared
		
		@FXML
	    private TableColumn<?, ?> fxtypenameCol;
		
		@FXML
		private ObservableList<ProductInfo> product;
		
		@FXML
		private Label error;
		Parent root;
		Stage stageuser;
		ProdTypeDAO proDAO = new ProdTypeDAO(); //created an object for the ProdTypeDAO.java class
		SelectedProdType seltype = new SelectedProdType();//created an object for the SelectedProdType.java class
		
		//this method is called when the admin wishes to delete any product type from the product types list
			public void delProducTypes(ActionEvent a) {
				System.out.println("Delete product button is clicked...");
				try {
					//the selected items are populated in the table
					ProductType pro = prods.getSelectionModel().getSelectedItem();
					if (pro == null)
						error.setText("Please select the Product Type");
						String protName = pro.getProdType();
						
						int prodtypeID = proDAO.fetchTypeID(protName);
						//query deletes the selected product
					boolean delete = proDAO.deleteProType(prodtypeID);
					if(delete)
					{
					JTextPane tp = new JTextPane();
					tp.setSize(new Dimension(500, 20));
					tp.setPreferredSize(new Dimension(500, tp.getPreferredSize().height));
					JOptionPane.showMessageDialog(null, "Deleted!");
					try{
						//redirects to the admin home page using FXML loader
						Parent rootGroup = FXMLLoader.load(getClass().getResource("/Controller/AdminHomePage.fxml"));
						Scene scene = new Scene(rootGroup,629,438);
						stageuser = (Stage) ((Node) a.getSource()).getScene().getWindow();
			    		stageuser.setScene(scene);
			    		stageuser.show();
					} catch (Exception e) {
						e.getMessage();
					}
					}
					else
						error.setText("Problem occured when deleting..");
					} catch (NumberFormatException e) {
						error.setText("Enter the valid input");
						e.getMessage();
					}
					}	
			//this method allows user to go back to the previous page
			public void goback2home(ActionEvent a){
				System.out.println("Back button is clicked...");
				try {
					//redirects to the admin home page using FXML loader
					Parent rootGroup = FXMLLoader.load(getClass().getResource("/Controller/AdminHomePage.fxml"));
					Scene scene = new Scene(rootGroup,629,438);
					stageuser = (Stage) ((Node) a.getSource()).getScene().getWindow();
		    		stageuser.setScene(scene);
		    		stageuser.show();
				} catch (Exception e) {
					e.getMessage();
				}
			}
			//this methods allows user to log out
				public void prodTypeLogout(ActionEvent a) {
					System.out.println("Logout button is clicked...");
					AdminLoginCont.adminLogout();
					try
					{
						//redirects to the admin login page using FXML loader
						Parent rootGroup = FXMLLoader.load(getClass().getResource("/Controller/AdminLogin.fxml"));
						Scene scene = new Scene(rootGroup,629,438);
						stageuser = (Stage) ((Node) a.getSource()).getScene().getWindow();
			    		stageuser.setScene(scene);
			    		stageuser.show();
					} catch (Exception e) {
						e.getMessage();
					}
					}
				@Override
				public void initialize(URL location, ResourceBundle resources) {
					// TODO Auto-generated method stub
					//connects the column fields to the fields in the product table
					fxtypenameCol.setCellValueFactory(new PropertyValueFactory<>("prodType"));
					ObservableList<ProductType> product = FXCollections.observableArrayList();
					try {
						statement = connect.getConnection().createStatement();
						//query selects the table fields for storing them in the table view
						String sqlprodtype = "Select typeName from producttype_table";
					
						rs = statement.executeQuery(sqlprodtype);

						while (rs.next()) {
							//adds all the fields to the table view
							product.add(new ProductType(rs.getString(1)));
							prods.setItems(product);
							
						}
						System.out.println("Type populated");	
					}
					catch (Exception e) {
						e.getMessage();
						e.printStackTrace();
						System.out.println("Exception is here");
					}
				
				}
}
				
			



