/**
 * Name : Priyanka Jagadesh Kumar 
 * Source File Name : AddProdCont.java
 * Phase-2: Winter wear Application
 * @author Priyanka Jagadesh Kumar
 * This class is used to add a product by the administrator
 * 
 **/
package Controller;

import java.awt.Dimension;
import java.util.List;

import javax.swing.JOptionPane;
import javax.swing.JTextPane;

import daoModel.ProdTypeDAO;
import daoModel.ProductinfoDAO;
import javafx.event.*;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
//import model.ProductInfo;
import model.ProductType;

public class AddProdCont {

//initiating the fields using FXML	
	@FXML
	private TextField productName;
	@FXML
	private ComboBox<String> ProductstypeList;
	@FXML
	private ComboBox<String> Availability;
	@FXML
	private TextField productPrice;
	@FXML
	private TextField productColor;
	@FXML
	private TextField productSize;
	@FXML
	private Label error;
	
	Parent root;
	Stage stageuser;
	
	ProductinfoDAO prodao = new ProductinfoDAO();//object creation for ProductinfoDAO.java class
	ProdTypeDAO protypedao = new ProdTypeDAO(); //object creation for ProdTypeDAO.java
	
	//initialize function is called fetch product types and values into the product type and availability combo boxes
	@FXML
	void initialize() {
		System.out.println("Fetching product types..");
		List<ProductType> name = protypedao.fetchType();
		for (ProductType types : name) {
			ProductstypeList.getItems().addAll(types.getProdType());	
				
		}
		Availability.getItems().addAll("YES","NO");
		System.out.println("Availability criteria is set!");
	}
	
	// This method is called when the admin clicks the submit button after entering all the details for the product
	public void addproduct(ActionEvent a) {
		System.out.println("Adding product..");
		String proName = productName.getText();
		String proType = ProductstypeList.getValue();
		String proAvail = Availability.getValue();
		String proPrice =  productPrice.getText();
		String proColor =  productColor.getText();
		String proSize = productSize.getText();
		try {
			if (proName.isEmpty() || proName == null)
				error.setText("Enter the Product Name");
			else if (proType.isEmpty() || proType == null)
				error.setText("Select the Product Type");
			else if (proAvail.isEmpty() || proAvail == null)
				error.setText("Select the Product Availability");
			else if (proPrice.isEmpty() || proPrice == null)
				error.setText("Please enter product price");
			else if (proColor.isEmpty() || proColor == null)
				error.setText("Please enter product color");
			else if (proSize.isEmpty() || proSize == null)
				error.setText("Select the Product Size");
			else {
				//getting the input values from the respective classes
				Double price = Double.parseDouble(proPrice);
				int proTypeID = protypedao.fetchTypeID(proType);
				//inserting the products into the product_type table
				boolean create = prodao.createProduct( proName,proType, proAvail,price,proColor, proSize,proTypeID);
				if (create) {
					System.out.println("The product is created!");
					//clears the text-boxes after the submit button is clicked
					productName.clear();
					productPrice.clear();
					productColor.clear();
					productPrice.clear();
					productSize.clear();
					//displays a dialogue box after a product is inserted into the table
					JTextPane tp = new JTextPane();
					tp.setSize(new Dimension(500, 20));
					tp.setPreferredSize(new Dimension(500, tp.getPreferredSize().height));
					JOptionPane.showMessageDialog(null, "Product is created!");
				 }
				else
					error.setText("Problem in creating a new Product");
			}
		}
		catch (NumberFormatException e) {
			error.setText("Enter the valid input");
		} catch (Exception e) {
			e.getMessage();
		}

		}
	//This method is called when the admin clicks back button and wants to go back to the admin home page 
	public void gobacktoadminhome(ActionEvent a){
		try {
			Parent rootGroup = FXMLLoader.load(getClass().getResource("/Controller/AdminHomePage.fxml"));
			Scene scene = new Scene(rootGroup, 629, 438);
			stageuser = (Stage) ((Node) a.getSource()).getScene().getWindow();

			stageuser.setScene(scene);
			stageuser.show();
		} catch (Exception e) {
			e.getMessage();
		}
	}
	//This method is called when the admin wishes to logout from his/her account. The logout button is clicked
		public void prodTypeLogout(ActionEvent a) {
			AdminLoginCont.adminLogout();
			try
			{
				Parent rootGroup = FXMLLoader.load(getClass().getResource("/Controller/AdminLogin.fxml"));
				Scene scene = new Scene(rootGroup, 629, 438);
				stageuser = (Stage) ((Node) a.getSource()).getScene().getWindow();

				stageuser.setScene(scene);
				stageuser.show();
			} catch (Exception e) {
				e.getMessage();
			}
			}
			
	}

