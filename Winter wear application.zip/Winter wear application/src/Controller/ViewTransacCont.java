/**
 * Name : Priyanka Jagadesh Kumar 
 * Source File Name : ViewTrasacCont.java
 * Phase-2: Winter wear Application
 * @author Priyanka Jagadesh Kumar
 * This class is called when the user wants to view the transactions made  
 * by the customer
 **/
package Controller;

import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ResourceBundle;

import daoModel.Connector;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import model.TransactionDetails;

//this class implements initializable method
public class ViewTransacCont implements Initializable{
	//connection is established and the result set in initialized
	static Connector connect = new Connector();
	static Connection conn;
	static Statement statement = null;
	ResultSet rs = null;
	//FXML variables are declared
	@FXML
	private TableView<TransactionDetails> trans;//table view is declared
	
	@FXML
    private TableColumn<?, ?> fxidCol;

    @FXML
    private TableColumn<?, ?> fxprodnameCol;

    @FXML
    private TableColumn<?, ?> fxquantCol;

    @FXML
    private TableColumn<?, ?> fxtotcostCol;

    @FXML
    private TableColumn<?, ?> fxdateCol;
    
    @FXML
	private ObservableList<TransactionDetails> transaction;
	Parent root;
	Stage stageuser;
	
	public void populateData(ObservableList<TransactionDetails> product) {
		this.trans.setItems(product);
		
	}
	//this method allows user to go back to the previous page
	public void gobacktocust(ActionEvent a){
		System.out.println("Back button is clicked...");
		try {
			//redirects to the customer home page using FXML loader
			Parent rootGroup = FXMLLoader.load(getClass().getResource("/Controller/CustHomePage.fxml"));
			Scene scene = new Scene(rootGroup,629,438);
			stageuser = (Stage) ((Node) a.getSource()).getScene().getWindow();
    		stageuser.setScene(scene);
    		stageuser.show();
		} catch (Exception e) {
			e.getMessage();
		}
	}
	//this methods allows user to log out
		public void transLogout(ActionEvent a) {
			System.out.println("Logout button is clicked...");
			AdminLoginCont.adminLogout();
			try
			{
				//redirects to the customer login page using FXML loader
				Parent rootGroup = FXMLLoader.load(getClass().getResource("/Controller/CustLoginPage.fxml"));
				Scene scene = new Scene(rootGroup,629,438);
				stageuser = (Stage) ((Node) a.getSource()).getScene().getWindow();
	    		stageuser.setScene(scene);
	    		stageuser.show();
			} catch (Exception e) {
				e.getMessage();
			}
			}

		@Override
		public void initialize(URL location, ResourceBundle resources) {
			// TODO Auto-generated method stub
			//connects the column fields to the fields in the product table
			fxidCol.setCellValueFactory(new PropertyValueFactory<>("transactionID"));
			fxprodnameCol.setCellValueFactory(new PropertyValueFactory<>("productName"));
			fxquantCol.setCellValueFactory(new PropertyValueFactory<>("quantity"));
			fxtotcostCol.setCellValueFactory(new PropertyValueFactory<>("totalPrice"));
			fxdateCol.setCellValueFactory(new PropertyValueFactory<>("transactionDate"));
			
			ObservableList<TransactionDetails> transaction = FXCollections.observableArrayList();
			try {
				statement = connect.getConnection().createStatement();
				//query selects the table fields for storing them in the table view
				String sqltran = "Select tranID, productName, quantity, totalPrice, tranDate from transaction_table";
			
				rs = statement.executeQuery(sqltran);

				while (rs.next()) {
					//adds all the fields to the table view
					transaction.add(new TransactionDetails(rs.getInt(1),rs.getString(2),rs.getInt(3),rs.getDouble(4),rs.getDate(5)));
				
					trans.setItems(transaction);
					
				}
				System.out.println("populated");
			} catch (Exception e) {
				e.getMessage();
				e.printStackTrace();
				System.out.println("Exception is here");
			}

		}
			
}
