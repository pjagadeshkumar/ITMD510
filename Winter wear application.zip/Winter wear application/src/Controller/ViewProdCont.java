/**
 * Name : Priyanka Jagadesh Kumar 
 * Source File Name : ViewProdCont.java
 * Phase-2: Winter wear Application
 * @author Priyanka Jagadesh Kumar
 * This class is called when the user wants to view the products available  
 * in the list
 **/
package Controller;


import java.awt.Dimension;
import java.net.URL;
//import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ResourceBundle;

import javax.swing.JOptionPane;
import javax.swing.JTextPane;

import daoModel.Connector;
import daoModel.ProductinfoDAO;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import model.ProductInfo;
import model.SelectedProd;

//this class implements initializable method
public class ViewProdCont implements Initializable{
	//connection is established and the result set in initialized
	static Connector connect = new Connector();
	//static Connection conn;
	static Statement statement = null;
	ResultSet rs = null;
//FXML variables are declared
	@FXML
    private TableView<ProductInfo> prodTableView; //table view is declared

    @FXML
    private TableColumn<?, ?> fxnameCol;

    @FXML
    private TableColumn<?, ?> fxtypeCol;

    @FXML
    private TableColumn<?, ?> fxavailCol;

    @FXML
    private TableColumn<?, ?> fxpriceCol;

    @FXML
    private TableColumn<?, ?> fxclrCol;

    @FXML
    private TableColumn<?, ?> fxsizeCol;
    
    @FXML
	private ObservableList<ProductInfo> product;
	
	@FXML
	private Label error;
	Parent root;
	Stage stageuser;
	ProductinfoDAO proDAO = new ProductinfoDAO(); //created an object for the ProductinfoDAO.java class 
	SelectedProd sel = new SelectedProd();//created an object for the SelectedProd.java class 
	
	//this method is called when the admin wishes to delete any item from the products list
		public void delProducts(ActionEvent a) {
			System.out.println("Delete product button is clicked...");
			try {
				//the selected items are populated in the table
				ProductInfo pro = prodTableView.getSelectionModel().getSelectedItem();
				if (pro == null)
					error.setText("Please select the Product");
					String proName = pro.getProductName();
				int productID = proDAO.fetchItemID(proName); //fetches the ID using product name
				//query deletes the selected product
				boolean delete = proDAO.deleteProduct(productID);
				System.out.println("deleted!");
				if(delete)
				{
				JTextPane tp = new JTextPane();
				tp.setSize(new Dimension(500, 20));
				tp.setPreferredSize(new Dimension(500, tp.getPreferredSize().height));
				JOptionPane.showMessageDialog(null, "Deleted!");
				try{
					//redirects to the admin home page using FXML loader
					Parent rootGroup = FXMLLoader.load(getClass().getResource("/Controller/AdminHomePage.fxml"));
					Scene scene = new Scene(rootGroup,629,438);
					stageuser = (Stage) ((Node) a.getSource()).getScene().getWindow();
		    		stageuser.setScene(scene);
		    		stageuser.show();

				} catch (Exception e) {
					e.getMessage();
				}
				}
				else
					error.setText("Problem occured when deleting..");
				} catch (NumberFormatException e) {
					error.setText("Enter the valid input");
					e.getMessage();
				}
				}	
		//this method allows user to go back to the previous page
		public void gobackhome(ActionEvent a){
			System.out.println("Back button is clicked...");
			try {
				//redirects to the admin home page using FXML loader
				Parent rootGroup = FXMLLoader.load(getClass().getResource("/Controller/AdminHomePage.fxml"));
				Scene scene = new Scene(rootGroup,629,438);
				stageuser = (Stage) ((Node) a.getSource()).getScene().getWindow();
	    		stageuser.setScene(scene);
	    		stageuser.show();
			} catch (Exception e) {
				e.getMessage();
			}
		}
		//this methods allows user to log out
			public void prodLogout(ActionEvent a) {
				System.out.println("Logout button is clicked...");
				AdminLoginCont.adminLogout();
				try
				{
					//redirects to the admin login page using FXML loader
					Parent rootGroup = FXMLLoader.load(getClass().getResource("/Controller/AdminLogin.fxml"));
					Scene scene = new Scene(rootGroup,629,438);
					stageuser = (Stage) ((Node) a.getSource()).getScene().getWindow();
		    		stageuser.setScene(scene);
		    		stageuser.show();
				} catch (Exception e) {
					e.getMessage();
				}
				}
			@Override
			public void initialize(URL location, ResourceBundle resources) {
				// TODO Auto-generated method stub
				//connects the column fields to the fields in the product table
				fxnameCol.setCellValueFactory(new PropertyValueFactory<>("productName"));
				fxtypeCol.setCellValueFactory(new PropertyValueFactory<>("productType"));
				fxavailCol.setCellValueFactory(new PropertyValueFactory<>("productAvailibility"));
				fxpriceCol.setCellValueFactory(new PropertyValueFactory<>("productPrice"));
				fxclrCol.setCellValueFactory(new PropertyValueFactory<>("productColor"));
				fxsizeCol.setCellValueFactory(new PropertyValueFactory<>("productSize"));
				
				ObservableList<ProductInfo> product = FXCollections.observableArrayList();
				
				try {
					statement = connect.getConnection().createStatement();
					//query selects the table fields for storing them in the table view
					String sqlprod = "Select productName,productType,productAvailibility,productSize,productColor,productPrice from product_table";
				
					rs = statement.executeQuery(sqlprod);

					while (rs.next()) {
						//adds all the fields to the table view
						product.add(new ProductInfo(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getDouble(6)));
						prodTableView.setItems(product);
						
					}
					System.out.println("populated");
				} catch (Exception e) {
					e.getMessage();
					e.printStackTrace();
					System.out.println("Exception is here");
				}

			}

			}
				
			
		
