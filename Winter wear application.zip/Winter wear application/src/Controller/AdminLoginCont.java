/**
 * Name : Priyanka Jagadesh Kumar 
 * Source File Name : AdminLoginCont.java
 * Phase-2: Winter wear Application
 * @author Priyanka Jagadesh Kumar
 * This class is used to ask the admin details from the administrator 
 * 
 **/
package Controller;

import daoModel.LoginDAO;
import javafx.event.*;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import model.AdminDetails;

import model.Login;

public class AdminLoginCont {
	//instantiating the variables with the help of FXML
	private static AdminDetails admin;
	@FXML
	private TextField usernameadmin;
	@FXML
	private PasswordField passwordadmin;
	@FXML
	private Label message;

	Parent root;
	Stage stageuser;

	Login log = new Login();//creates an object for the Login.java class
	LoginDAO logdao = new LoginDAO();//creates an object for the LoginDAO.java class

	//This method validates the credentials entered by the admin by the click of submit button
	public void signupvalidation(ActionEvent a) {
		System.out.println("Enter the login details:");
		AdminDetails ad = new AdminDetails();
		String admin_loginID = usernameadmin.getText();
		String admin_password = passwordadmin.getText();
		if (admin_loginID == null || admin_loginID.isEmpty())
			message.setText("Enter username");
		else if (admin_password == null || admin_password.isEmpty())
			message.setText("Enter password");
		else {
			log.setUsername(admin_loginID);
			log.setPassword(admin_password);			
			ad = logdao.administratorDetails(log);
			if (ad.getAdmin_loginID().equals(admin_loginID) && ad.getAdmin_password().equals(admin_password)) {
				admin = ad;
				System.out.println("You have successfully signed in!");
				try {
					//This redirects the user to 
					Parent rootGroup = FXMLLoader.load(getClass().getResource("/Controller/AdminHomePage.fxml"));
					Scene scene = new Scene(rootGroup, 629, 438);
					stageuser = (Stage) ((Node) a.getSource()).getScene().getWindow();
					stageuser.setScene(scene);
					stageuser.show();
				} catch (Exception e) {
					e.printStackTrace();
				}

			} else
				System.out.println("Enter valid username and password");
		}
	}
//This method is called when the admin clicks back button and wants to go back to the Main page
	public void goback3(ActionEvent a) {

		try {
			Parent rootGroup = FXMLLoader.load(getClass().getResource("/Controller/MainPage.fxml"));
			Scene scene = new Scene(rootGroup, 629, 438);
			stageuser = (Stage) ((Node) a.getSource()).getScene().getWindow();

			stageuser.setScene(scene);
			stageuser.show();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public static AdminDetails getAdmin() {
		return admin;
	}
	//This method is called when the admin wishes to logout from his/her account. The logout button is clicked
	public static void adminLogout() {
		admin = null;
	}
}
