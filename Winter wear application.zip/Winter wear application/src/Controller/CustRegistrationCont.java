/**
 * Name : Priyanka Jagadesh Kumar 
 * Source File Name : CustRegistrationCont.java
 * Phase-2: Winter wear Application
 * @author Priyanka Jagadesh Kumar
 * This class is called when a customer needs to register a new account 
 * 
 **/
package Controller;

import java.awt.Dimension;
import javafx.scene.control.TextField;


import javax.swing.JOptionPane;
import javax.swing.JTextPane;

import daoModel.CustDAO;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.stage.Stage;

import javafx.event.ActionEvent;
//import java.awt.event.ActionEvent;

public class CustRegistrationCont {
//declaring the variables for FXML components 
	@FXML
	private TextField firstnam;
	@FXML
	private TextField lastnam;
	@FXML
	private TextField uname;
	@FXML
	private TextField passwrd;
	@FXML
	private TextField addressone;
	@FXML
	private TextField addresstwo;
	@FXML
	private TextField country;
	@FXML
	private TextField state;
	@FXML
	private TextField zipcode;
	@FXML
	private Label error;
	
	Parent root;
	Stage stageuser;
	CustDAO cd = new CustDAO();
	
	//this method is called when the customer clicks registor button
	public void RegisterNewCust(ActionEvent a) 
	{
		System.out.println("Register button is clicked...");
		//gets the values from the customer
		String firstName = firstnam.getText();
		String lastName = lastnam.getText();
		String username = uname.getText();
		String password = passwrd.getText();
		String address1 = addressone.getText();
		String address2 = addresstwo.getText();
		String cus_country = country.getText();
		String cus_State = state.getText();
		String pinCode = zipcode.getText();
		
		if (firstName == null || firstName.isEmpty())
			error.setText("Enter your first name");
		else if (lastName == null || lastName.isEmpty())
			error.setText("Enter your last name");
		else if (username == null || username.isEmpty())
			error.setText("Enter the username");
		else if (password == null || password.isEmpty())
			error.setText("Enter the password");
		else if (address1 == null || address1.isEmpty())
			error.setText("Enter your Address Line 1");
		else if (address2 == null || address2.isEmpty())
			error.setText("Enter your Address Line 2");
		else if (cus_country == null || cus_country.isEmpty())
			error.setText("Enter the city name");
		else if (cus_State == null || cus_State.isEmpty())
			error.setText("Enter the state");
		else if (pinCode == null || pinCode.isEmpty())
			error.setText("Enter the zipcode");
		else {
			
		try
		{
			
			Integer custzipcode = Integer.parseInt(pinCode);
			//stores the values entered by the user into the customer table
			boolean newcust = cd.newCustomer(lastName, firstName,  username, password, address1, address2, cus_country, cus_State, custzipcode);
			System.out.println("inserted!");
			if(newcust)
			{
				firstnam.clear();
				lastnam.clear();
				uname.clear();
				passwrd.clear();
				addressone.clear();
				addresstwo.clear();
				country.clear();
				state.clear();
				zipcode.clear();
				
				System.out.println("after clear");
				JTextPane tp = new JTextPane();
				tp.setSize(new Dimension(500, 20));
				tp.setPreferredSize(new Dimension(500, tp.getPreferredSize().height));
				JOptionPane.showMessageDialog(null, "Your account has been created!");
				try {
					//redirects to the customer login page using loader
					Parent rootGroup = FXMLLoader.load(getClass().getResource("/Controller/CustLoginPage.fxml"));
					Scene scene = new Scene(rootGroup,629,438);
					stageuser = (Stage) ((Node) a.getSource()).getScene().getWindow();

					stageuser.setScene(scene);
					stageuser.show();
				} catch (Exception e) {
					e.getMessage();
				}
			}
		
		
					else
						error.setText("A error has occured in creating a new profile!");
				} catch (NumberFormatException e) {
					error.setText("Enter the valid input");
					e.getMessage();
				}
					
			}
	}
	
	//this method clears the values in the text field after the customer clicks clear
	public void clearInputX(ActionEvent a) {
		System.out.println("Clear button is clicked...");
		firstnam.clear();
		lastnam.clear();
		uname.clear();
		passwrd.clear();
		addressone.clear();
		addresstwo.clear();
		country.clear();
		state.clear();
		zipcode.clear();
	}

	//goes to the previous page when back button is clicked
	public void goback2mainpage(ActionEvent a) {
		System.out.println("back button is clicked...");
		try {
			//redirects to the main page using Fx
			Parent rootGroup = FXMLLoader.load(getClass().getResource("/Controller/MainPage.fxml"));
			Scene scene = new Scene(rootGroup, 629, 438);
			stageuser = (Stage) ((Node) a.getSource()).getScene().getWindow();
            stageuser.setScene(scene);
			stageuser.show();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	}